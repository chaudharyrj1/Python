class Course:
    def getCourse(self):
        return self.course
    def setCourse(self,course):
        self.course=course
