class Student:
    def getName(self):
        return self.name
    def getRollNo(self):
        return self.rollno
    def setName(self, name):
        self.name=name
    def setRollNo(self, rollno):
        self.rollno=rollno
    def getCourses(self):
        return self.courses
    def setCourses(self, courses):
        self.courses = courses
