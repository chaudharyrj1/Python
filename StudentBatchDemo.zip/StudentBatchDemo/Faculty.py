class Faculty:
    def getID(self):
        return self.ID
    def setID(self,ID):
        self.ID=ID
    def getName(self):
        return self.name
    def setName(self,name):
        self.name=name
    def getCourse(self):
        return self.course
    def setCourse(self,course):
        self.course=course