class Batch:
    def getID(self):
        return self.ID
    def setID(self,ID):
        self.ID=ID
    def getCourse(self):
        return self.course
    def setCourse(self, course):
        self.course = course
    def getFaculty(self):
        return self.faculty
    def setFaculty(self, faculty):
        self.faculty = faculty
    def getStudents(self):
        return self.students
    def setStudents(self, students):
        self.students = students