from Student import Student

class StudentSchedular:
    students = []

    def addStudents(self, name, rollno, courses):
        student = Student()
        student.setName(name)
        student.setRollNo(rollno)
        student.setCourses(courses)
        self.students.append(student)

    def showAllStudents(self):
        return self.students

    def getStudentDetailsByRollNo(self, rollno):
        flag = 0
        for student in self.showAllStudents():
            if (student.getRollNo() == rollno):
                flag = 1
                return student
        if (flag == 0):
            return None