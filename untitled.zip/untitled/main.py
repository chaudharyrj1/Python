from StudentSchedular import StudentSchedular

studentSchedular = StudentSchedular()
flag = 0

def addStudent(self):
    courses = []
    rollno = input("enter rollno: ")
    if studentSchedular.getStudentDetailsByRollNo is None:
        name = input("enter name: ")
        n = input("enter number of courses: ")
        for i in range(n):
            course = input("enter course: ")
            courses.append(course)
        studentSchedular.addStudent(name, rollno, courses)
    else:
        print("Roll No already exists")


def displayStudents(self):
    count = 1
    students = studentSchedular.showAllStudents()
    if students == []:
        print('No Student Available')
    else:
        for student in students:
            print('Student ', count, ' Details: ')
            print('Name: ', student.getName())
            print('Roll Number: ', student.getRollNo())
            print('Courses: '.student.getCourses())
            count += 1


def displayStudentDetailsByRollNo(self, rollno):
    student = studentSchedular.getStudentDetailsByRollNo(rollno)
    if student is None:
        print('No Student Available for this Roll No')
    else:
        print('Student Details for Roll No ', rollno, ' : ')
        print('Name: ', student.getName())
        print('Roll Number: ', student.getRollNo())
        print('Courses: '.student.getCourses())


while (flag == 0):
    str = input("1. Add Student\n2. View Reports \n3. Exit\n")
    print str
    if str == "1":
        addStudent()
    elif (str == "2"):
        choice = input("1. Display Students\n2. Display Student Details by Roll No\n")
        if (choice == "1"):
            displayStudents()
        elif (choice == "2"):
            rollno = input("Enter Roll Number: ")
            displayStudentDetailsByRollNo(rollno)
        else:
            print("Please Choose Valid Option")
    elif (str == "3"):
        break;
    else:
        print("\nPlease Enter Valid Input\n")